package edu.westga.cs6312.fishing.tests;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.fishing.model.FishingHole;

/**
 * Junit test to getLocation method. Tests two different locations
 */
class FishingHoleWhenGetLocation {

	@Test
	void fishingHoleTestGetLocation() {
		FishingHole testFishHole = new FishingHole(1);
		assertEquals("Fishing hole at [1]", testFishHole.getLocation());
	}

	@Test
	void fishingHoleTestGetLocationWithDifferentLocation() {
		FishingHole anotherFishingHole = new FishingHole(5);
		assertEquals("Fishing hole at [5]", anotherFishingHole.getLocation());
	}

}
