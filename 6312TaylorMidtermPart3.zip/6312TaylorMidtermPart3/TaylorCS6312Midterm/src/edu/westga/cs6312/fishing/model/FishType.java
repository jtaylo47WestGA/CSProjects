package edu.westga.cs6312.fishing.model;

/**
 * Abstract class represents a type of fish
 * 
 * @author Joshua Taylor
 * @version 2/17/2024
 */

public abstract class FishType {
	private int numberOfFish;

	/**
	 * 1 parameter constructor to set the initial fish count
	 * 
	 * @param initialFishCount user supplied number of fish
	 */
	public FishType(int initialFishCount) {
		this.numberOfFish = initialFishCount;
	}

	/**
	 * Getter method to return the number of fish
	 * 
	 * @return numberOfFish represents number of fish
	 */
	public int getNumberOfFish() {
		return this.numberOfFish;
	}

	/**
	 * method is used to remove a user supplied amount of fish
	 * 
	 * @param numberFishToRemove user supplied number of fish to remove
	 */
	public void removeFish(int numberFishToRemove) {
		if (numberFishToRemove > 0 && numberFishToRemove <= this.numberOfFish) {
			this.numberOfFish -= numberFishToRemove;
			System.out.println(numberFishToRemove + " fish removed from the school.");
		} else {
			System.out.println("Invalid number of fish to remove.");
		}
	}

	/**
	 * Abstract method to represent the amount of small or large fish caught
	 * 
	 * @return fishCaught number of large/small fish caught
	 */
	public abstract int catchFish();

	/**
	 * Abstract method to represent the amount it costs to fish for small or large
	 * fish
	 * 
	 * @return COST_TO_FISH number is costs to catch large or small fish
	 */
	public abstract double costToFish();

	/**
	 * Override toString method to represent the amount of fish in the school
	 * 
	 * @return numberOfFish represents fish in the school
	 */
	@Override
	public String toString() {
		return this.numberOfFish + " fish in the school ";
	}

}
