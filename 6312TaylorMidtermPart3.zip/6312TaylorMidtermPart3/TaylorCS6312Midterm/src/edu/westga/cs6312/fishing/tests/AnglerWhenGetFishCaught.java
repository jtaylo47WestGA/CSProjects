package edu.westga.cs6312.fishing.tests;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.fishing.model.Angler;

/**
 * Junit test to test Angler getFish method
 * 
 * @author Joshua Taylor
 * @version 2/17/2024
 */
class AnglerWhenGetFishCaught {

	@Test
	void anglerTestFishCaughtAccessorMethod() {
		Angler testAngler = new Angler();
		assertEquals(0, testAngler.getFishCaught());
	}
}
