package edu.westga.cs6312.fishing.tests;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.fishing.model.SmallFish;

/**
 * Junit test to test smallFish creation
 * 
 * @author Joshua Taylor
 * @version 2/17/2024
 */
class SmallFishWhenCreateSmallFish {

	@Test
	void smallFishCreateSmallFish() {
		SmallFish testSmallFish = new SmallFish();
		assertEquals("small fish with 100 fish in the school", testSmallFish.toString());
	}

}
