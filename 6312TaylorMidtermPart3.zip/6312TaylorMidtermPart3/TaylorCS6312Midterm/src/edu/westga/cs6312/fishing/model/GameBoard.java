package edu.westga.cs6312.fishing.model;

/**
 * Class the represents a the gameboard for the fishing hole game
 * 
 * @author Joshua Taylor
 * @version 2/17/2024
 */
public class GameBoard {
	private FishingHole[] fishingHoles;
	private Angler newFisherMan;
	private int currentLocation;

	/**
	 * Constructor to initialize the fishing hole, angler, and location
	 */
	public GameBoard() {
		this.setupFishingHoles();
		this.currentLocation = 0;
		this.newFisherMan = new Angler();
	}

	/**
	 * setupFishingHoles method initializes array of fishingHoles and creates a new
	 * angler
	 */
	private void setupFishingHoles() {
		this.fishingHoles = new FishingHole[10];
		for (int userCount = 0; userCount < 10; userCount++) {
			this.fishingHoles[userCount] = new FishingHole(userCount);
		}
	}

	/**
	 * Getter method to return the representation of the angler
	 * 
	 * @return newFisherMan representation of angler
	 */
	public Angler getAngler() {
		return this.newFisherMan;
	}

	/**
	 * method to return the current fishinghole location
	 * 
	 * @return currentLocation represents the current fishing hole location
	 */
	public int getCurrentLocation() {
		return this.currentLocation;
	}

	/**
	 * method to return the locations fishing hole
	 * 
	 * @return fishingHoles representations of the current fishingHole using it's
	 *         toString method
	 */
	public String getFishingHole() {
		return this.fishingHoles[this.currentLocation].toString();
	}

	/**
	 * moveUp method moves the angler's fishingHole location backward by one
	 * location
	 */
	public void moveUp() {
		if (this.currentLocation == 0) {
			this.currentLocation = (this.currentLocation - 1 + 10) % 10;
		} else {
			this.currentLocation = (this.currentLocation - 1);
		}
	}

	/**
	 * moveDown method moves the angler's fishingHole location forward by one
	 * location
	 */
	public void moveDown() {
		this.currentLocation = (this.currentLocation + 1) % 10;
	}

	/**
	 * anglerFishCurrentLocation allows the angler pay to fish in a location and to
	 * track how many fish are caught
	 */
	public void anglerFishCurrentLocation() {
		if (this.fishingHoles[this.currentLocation].getFish() == null) {
			System.out.println("There are no fish at this location.");
		} else {
			this.currentLocation = this.getCurrentLocation();
			int anglerPay = (int) this.fishingHoles[this.currentLocation].setNumberAnglerCostLeft();
			this.newFisherMan.payToFish(anglerPay);
			System.out.println("the number of fish caught " + this.fishingHoles[this.currentLocation].getFish());
			int fishCaught = this.fishingHoles[this.currentLocation].setNumberOfFishLeft();
			this.newFisherMan.catchFish(fishCaught);
			System.out.println("the fish left in the fishing hole is  " + this.newFisherMan.getFishCaught()
					+ " the amount of cash left is " + this.newFisherMan.getMoneyUnitsLeft());
		}
	}

	/**
	 * Overrides the toString method and represents the current state of the
	 * gameboard
	 */
	@Override
	public String toString() {
		String userReturnString = "";
		for (int userCount = 0; userCount < 10; userCount++) {
			userReturnString += this.fishingHoles[userCount].toString() + " \n";
		}

		userReturnString += "\n" + this.newFisherMan.toString();
		return userReturnString;
	}

}
