package edu.westga.cs6312.fishing.view;

import java.util.Scanner;
import edu.westga.cs6312.fishing.model.GameBoard;

/**
 * Represents the Text Based User Interface for the game
 * 
 * @author Joshua Taylor
 * @version 2/17/2024
 */
public class FishingTUI {
	private GameBoard gameBoard;
	private Scanner userInputScanner;

	/**
	 * Constructor that initializes the TUI with the gameBoard and an input scanner
	 * 
	 * @param gameBoard representation of gameBoard
	 */
	public FishingTUI(GameBoard gameBoard) {
		this.gameBoard = gameBoard;
		this.userInputScanner = new Scanner(System.in);
	}

	/**
	 * Gets users choice as string and converts to an integer
	 * 
	 * @return userChoice users inputed choice to TUI
	 */
	private int getIntegerFromUser() {

		String userInputString = this.userInputScanner.nextLine();
		int userChoice = Integer.parseInt(userInputString);
		try {
			return userChoice;
		} catch (NumberFormatException error) {
			System.out.println("Invalid input. Please enter a valid integer.");

		}
		return userChoice;

	}

	/**
	 * displayMenu presents user with options to run the program and calls the
	 * methods based on user input
	 */
	public void displayMenu() {
		System.out.println("Welcome to Down by the Fishin' Hole");
		while (true) {
			System.out.println("\n1 - Describe current fishing hole");
			System.out.println("2 - Describe angler");
			System.out.println("3 - Describe game board");
			System.out.println("4 - Move");
			System.out.println("5 - Fish the Fishing Hole");
			System.out.println("9 - Quit");
			int choice = this.getIntegerFromUser();
			switch (choice) {
			case 1:
				System.out.println(this.gameBoard.getCurrentLocation());
				System.out.println(this.gameBoard.getFishingHole());
				break;
			case 2:
				System.out.println(this.gameBoard.getAngler().toString());
				break;
			case 3:
				System.out.println(this.gameBoard.toString());
				break;
			case 4:
				this.displayMovementMenu();
				break;
			case 5:
				this.gameBoard.anglerFishCurrentLocation();
				break;
			case 9:
				System.out.println("Exiting. Goodbye!");
				return;
			default:
				System.out.println("Invalid choice. Please select a valid option.");
			}
		}
	}

	/**
	 * displays menu for the moveUp/moveDown, gets user input and calls the moveUp
	 * or moveDown methods
	 */
	public void displayMovementMenu() {
		System.out.println("Enter your movement selection:");
		System.out.println("1 - Move up");
		System.out.println("2 - Move down");

		int choice = this.getIntegerFromUser();
		System.out.println(choice);
		switch (choice) {
		case 1:
			this.gameBoard.moveUp();
			break;
		case 2:
			this.gameBoard.moveDown();
			break;
		default:
			System.out.println("Invalid choice. Please select a valid option.");
		}
	}

	/**
	 * run method calls the displayMenu method
	 */
	public void run() {
		this.displayMenu();
	}

}
