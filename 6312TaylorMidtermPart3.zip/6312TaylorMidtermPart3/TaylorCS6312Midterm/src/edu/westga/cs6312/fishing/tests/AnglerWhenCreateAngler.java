package edu.westga.cs6312.fishing.tests;

import static org.junit.Assert.assertEquals;
import edu.westga.cs6312.fishing.model.Angler;

import org.junit.jupiter.api.Test;

/**
 * Junit test to test Angler constructor and toString method
 * 
 * @author Joshua Taylor
 * @version 2/18/2024
 */
class AnglerWhenCreateAngler {

	@Test
	void anglerTestCreateAnglerToString() {
		Angler testAngler = new Angler();
		assertEquals("Angler: Money Units Left = 100, Fish Caught = 0", testAngler.toString());
	}

}
