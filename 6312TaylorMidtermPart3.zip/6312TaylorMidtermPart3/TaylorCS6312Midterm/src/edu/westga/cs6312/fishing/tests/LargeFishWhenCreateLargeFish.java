package edu.westga.cs6312.fishing.tests;

import static org.junit.Assert.assertEquals;
import edu.westga.cs6312.fishing.model.LargeFish;

import org.junit.jupiter.api.Test;

/**
 * Junit Test tests creation of a large fish
 * 
 * @author Joshua Taylor
 * @version 2/17/2024
 */
class LargeFishWhenCreateLargeFish {

	@Test
	void largeFishTestCreate() {
		LargeFish testLargeFish = new LargeFish();
		assertEquals("large fish with 50 fish in the school", testLargeFish.toString());
	}
}
