package edu.westga.cs6312.fishing.model;

/**
 * Class the represents an Angler
 * 
 * @author Joshua Taylor
 * @version 2/17/2024
 */

public class Angler {
	private int moneyUnitsLeft;
	private int fishCaught;

	/**
	 * Zero parameter constructor that initializes the amount of fish caught and
	 * money left
	 */
	public Angler() {
		this.moneyUnitsLeft = 100;
		this.fishCaught = 0;
	}

	/**
	 * Getter method to return the amount of money an angler has left
	 * 
	 * @return moneyUnitsLeft money an angler has left
	 */
	public int getMoneyUnitsLeft() {
		return this.moneyUnitsLeft;
	}

	/**
	 * Getter method to return the amount of fish an angler has caught
	 * 
	 * @return fishCaught the amount of fish caught
	 */
	public int getFishCaught() {
		return this.fishCaught;
	}

	/**
	 * Method to pay for an angler to fish at fishing hole
	 * 
	 * @param payment user Supplied payment amount
	 */
	public void payToFish(int payment) {
		if (payment > 0 && this.moneyUnitsLeft >= payment) {
			this.moneyUnitsLeft -= payment;
			System.out.println("You paid " + payment + " money units to fish.");
		} else {
			System.out.println("Insufficient funds to fish.");
		}
	}

	/**
	 * Method to catch the number of fish for an angler
	 * 
	 * @param numberOfFish user supplied number of fish caught
	 */
	public void catchFish(int numberOfFish) {
		if (numberOfFish > 0) {
			this.fishCaught += numberOfFish;
			System.out.println("You caught " + numberOfFish + " fish.");
		} else {
			System.out.println("Invalid number of fish caught.");
		}
	}

	/**
	 * Overide toString method that represents an anglers money left and fish caught
	 */
	@Override
	public String toString() {
		return "Angler: Money Units Left = " + this.moneyUnitsLeft + ", Fish Caught = " + this.fishCaught;
	}

}
