package edu.westga.cs6312.fishing.controller;

import edu.westga.cs6312.fishing.view.FishingTUI;
import edu.westga.cs6312.fishing.model.GameBoard;

/**
 * Driver for the fishing TUI and starts the game.
 * 
 * @author Joshua Taylor
 * @version 2/17/2024
 */
public class FishingDriver {

	/**
	 * creates a gameBoard and passes it to the TUI
	 * 
	 * @param args not used
	 */
	public static void main(String[] args) {
		GameBoard gameBoard = new GameBoard();
		FishingTUI fishingGame = new FishingTUI(gameBoard);
		fishingGame.run();
	}

}
