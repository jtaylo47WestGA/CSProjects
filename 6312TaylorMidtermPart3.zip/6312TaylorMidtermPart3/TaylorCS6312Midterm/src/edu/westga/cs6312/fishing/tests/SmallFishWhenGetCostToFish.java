package edu.westga.cs6312.fishing.tests;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.fishing.model.SmallFish;

/**
 * Junit tests the costToFish smallFish method to report the correct double
 * value
 */
class SmallFishWhenGetCostToFish {

	@Test
	void smallFishTestCostToFish() {
		SmallFish testSmallFish = new SmallFish();
		double delta = 0.001;
		assertEquals(25.0, testSmallFish.costToFish(),delta);
	}

}
