package edu.westga.cs6312.fishing.model;

import java.util.Random;

/**
 * Class the extends the Fishtype to represent a large fish sets
 * max_fish_to_catch to 50 and cost_to_fish to 50
 * 
 * @author Joshua Taylor
 * @version 2/17/2024
 */
public class LargeFish extends FishType {
	private static final int MAX_FISH_TO_CATCH = 50;
	private static final double COST_TO_FISH = 50.0;

	/**
	 * Zero parameter contructor that calls the superclass with the max fish to
	 * catch
	 */
	public LargeFish() {
		super(MAX_FISH_TO_CATCH);
	}

	/**
	 * catchFish represents the number of largeFish caught
	 * 
	 * @return fishCaught number of largeFish that are caught
	 */
	@Override
	public int catchFish() {
		int numberOfLargeFish = this.getNumberOfFish();
		Random random = new Random();
		int fishCaught = random.nextInt(numberOfLargeFish + 1);
		numberOfLargeFish -= fishCaught;
		return fishCaught;
	}

	/**
	 * Overrides the costToFish to represent the cost to fish for largeFish
	 * 
	 * @return COST_TO_FISH Constant to fish largeFish
	 */
	@Override
	public double costToFish() {
		return COST_TO_FISH;
	}

	/**
	 * Overrides toString method to represent a school of largeFish @
	 */
	@Override
	public String toString() {
		int numberOfLargeFish = this.getNumberOfFish();
		String largeFishSchool = "large fish with " + numberOfLargeFish + " fish in the school";
		return largeFishSchool;
	}
}
