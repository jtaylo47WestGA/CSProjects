package edu.westga.cs6312.fishing.model;

/**
 * Class the represents a fishing hole
 * 
 * @author Joshua Taylor
 * @version 2/17/2024
 */
public class FishingHole {
	private FishType fishType;
	private int location;

	/**
	 * One parameter constructor to instantiate a fishing hole
	 * 
	 * @param location user supplied number location of fishing hoe
	 */
	public FishingHole(int location) {
		this.location = location;
		this.setupFishingHole();
	}

	/**
	 * setupFishingHole gives a 50% chance of stocking the fishing hole with fish
	 */
	private void setupFishingHole() {
		if (Math.random() < 0.5) {
			this.fishType = this.addFish();
		}
	}

	/**
	 * The addFish method has a 50% chance of stocking the fish with small or larger
	 * fish
	 * 
	 * @return FishType returns either small or large fish type
	 */
	private FishType addFish() {

		if (Math.random() < 0.5) {
			return new SmallFish();
		} else {
			return new LargeFish();
		}
	}

	/**
	 * Getter method to return to fishing hole location
	 * 
	 * @return fishingHoleLocation fishing hole location
	 */
	public String getLocation() {
		String fishingHoleLocation = "Fishing hole at [" + this.location + "]";
		return fishingHoleLocation;
	}

	/**
	 * Method to get the fish type of the fishing hole
	 * 
	 * @return fishType type of fish for the fishing hole
	 */
	public FishType getFish() {
		return this.fishType;
	}

	/**
	 * Call the abstract catchFish method to get the number of small or large fish
	 * caught
	 * 
	 * @return numberOfFishCaught number of fish caught by angler at fishing hole
	 */
	public int setNumberOfFishLeft() {
		int numberOfFishCaught = this.fishType.catchFish();
		this.fishType.removeFish(numberOfFishCaught);
		return numberOfFishCaught;
	}

	/**
	 * Call the abstract method costToFish to get the cost to fish small or large
	 * fish
	 * 
	 * @return anglerCostToFish cost of to fish either small or large fish
	 */
	public double setNumberAnglerCostLeft() {
		double anglerCostToFish = this.fishType.costToFish();
		return anglerCostToFish;

	}

	/**
	 * Overide of toString method to represent a fishing hole
	 */
	@Override
	public String toString() {
		if (this.fishType == null) {
			return "Fishing hole at location " + this.location + " containing no fish";
		} else {
			return "Fishing hole at location " + this.location + " with fish: " + this.fishType;
		}
	}

}
