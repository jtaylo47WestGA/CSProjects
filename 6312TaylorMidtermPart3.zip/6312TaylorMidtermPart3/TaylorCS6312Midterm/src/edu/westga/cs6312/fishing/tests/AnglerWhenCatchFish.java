package edu.westga.cs6312.fishing.tests;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.fishing.model.Angler;

/**
 * Junit test to test Angler catchFish method
 * 
 * @author Joshua Taylor
 * @version 2/18/2024
 */
class AnglerWhenCatchFish {

	@Test
	void anglerTestWhenCatchFish() {
		Angler testAngler = new Angler();
		testAngler.catchFish(37);
		assertEquals(37, testAngler.getFishCaught());

	}
}
