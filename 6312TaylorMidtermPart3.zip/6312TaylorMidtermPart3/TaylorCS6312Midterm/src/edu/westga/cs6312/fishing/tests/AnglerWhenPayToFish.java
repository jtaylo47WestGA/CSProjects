package edu.westga.cs6312.fishing.tests;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.fishing.model.Angler;

/**
 * Junit test to test the payToFish Angler method
 * 
 * @author Joshua Taylor
 * @version 2/17/2024
 */
class AnglerWhenPayToFish {

	@Test
	void anglerTestWhenPaytoFishAccessorMethod() {
		Angler testAngler = new Angler();
		testAngler.payToFish(40);
		assertEquals(60, testAngler.getMoneyUnitsLeft());

	}
}
