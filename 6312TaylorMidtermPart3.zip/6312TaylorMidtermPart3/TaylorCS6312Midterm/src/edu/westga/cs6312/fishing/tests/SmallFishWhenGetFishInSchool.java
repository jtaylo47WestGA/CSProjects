package edu.westga.cs6312.fishing.tests;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.fishing.model.SmallFish;

/**
 * Junit test the small fish getNumberOfFish method for correct value
 */
class SmallFishWhenGetFishInSchool {

	@Test
	void smallFishTestAccessMethod() {
		SmallFish testSmallFish = new SmallFish();
		assertEquals(100, testSmallFish.getNumberOfFish());
	}

}
