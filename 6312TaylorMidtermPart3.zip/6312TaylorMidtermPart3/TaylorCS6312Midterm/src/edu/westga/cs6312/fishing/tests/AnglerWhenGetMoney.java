package edu.westga.cs6312.fishing.tests;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.fishing.model.Angler;

/**
 * Junit to test Angler getMoneyUnitsLeft method
 */
class AnglerWhenGetMoney {

	@Test
	void anglerTestMoneyAccessorMethod() {
		Angler testAngler = new Angler();
		assertEquals(100, testAngler.getMoneyUnitsLeft());
	}

}
