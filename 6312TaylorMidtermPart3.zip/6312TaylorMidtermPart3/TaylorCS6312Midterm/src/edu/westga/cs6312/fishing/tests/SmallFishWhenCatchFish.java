package edu.westga.cs6312.fishing.tests;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.fishing.model.SmallFish;

/**
 * Junit test to test smallFish catchFish method
 * 
 * @author Joshua Taylor
 * @version 2/17/2024
 */
class SmallFishWhenCatchFish {

	@Test
	void smallFishTestCatchFish() {
		SmallFish testSmallFish = new SmallFish();
		testSmallFish.catchFish();
		assertEquals(100, testSmallFish.getNumberOfFish());

	}

}
