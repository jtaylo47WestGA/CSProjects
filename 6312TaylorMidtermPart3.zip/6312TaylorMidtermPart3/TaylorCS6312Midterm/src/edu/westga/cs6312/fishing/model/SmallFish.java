package edu.westga.cs6312.fishing.model;

/**
 * SmallFish extends the Fishtype and sets the fish count to 100
 * 
 * @author Joshua Taylor
 * @version 2/17/2024
 */
public class SmallFish extends FishType {
	/**
	 * Constructor that calls the super class and sets the fish count to 100
	 */
	public SmallFish() {
		super(100);
	}

	/**
	 * Override the costToFish method to set the small fish cost
	 * 
	 * @return smallFishCost cost o catch small fish
	 */
	@Override
	public double costToFish() {
		double smallFishCost = 25;
		return smallFishCost;
	}

	/**
	 * Override the catchFish method to represent number of smallFish caught
	 * 
	 * @return fishCaught represents number of smallFish caught
	 */
	@Override
	public int catchFish() {
		int numberOfSmallFish = this.getNumberOfFish();
		int fishCaught = Math.min(numberOfSmallFish, 50);
		numberOfSmallFish -= fishCaught;
		return fishCaught;
	}

	/**
	 * Override of toString method to represent the school of smallFish
	 * @return smallFishSchool number of fish in the smallFish school
	 */
	@Override
	public String toString() {
		int numberOfSmallFish = this.getNumberOfFish();
		String smallFishSchool = "small fish with " + numberOfSmallFish + " fish in the school";
		return smallFishSchool;
	}

}
